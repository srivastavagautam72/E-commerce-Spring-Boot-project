import logo from './logo.png';
import upload from './upload.png'
import login from './login-bg.jpg';
import profile from './profile.png';
import device from './device.png';

export const assets = {
    logo,
    upload,
    login,
    profile,
    device
}